# embroidery-inventory-manager
